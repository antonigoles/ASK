/* mismatch-a.c */
void p2(void);

int main() {
  p2();
  return 0;
}
