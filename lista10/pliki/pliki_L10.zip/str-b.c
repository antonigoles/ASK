char *somestr(void) {
  return "Hello, world!";
}
